<?php 
class ProjectVendor extends My_Model{
    protected $table = 'db_project_vendor';
    
}
