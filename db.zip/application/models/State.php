<?php 
class State extends My_Model{
    protected $table = 'db_state';
    
}
