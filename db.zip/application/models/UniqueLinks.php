<?php 
class UniqueLinks extends My_Model{
    protected $table = 'db_unique_links';
    
}
