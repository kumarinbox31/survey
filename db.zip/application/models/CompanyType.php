<?php 
class CompanyType extends My_Model{
    protected $table = 'company_type';
    
}
