<?php 
class Setting extends My_Model{
    protected $table = 'db_settings';
    
}
