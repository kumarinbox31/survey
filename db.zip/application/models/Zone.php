<?php 
class Zone extends My_Model{
    protected $table = 'db_zone';
    
}
