<?php 
class Response extends My_Model{
    protected $table = 'db_response';
    
}
