<?php 
class ContactGroup extends My_Model{
    protected $table = 'contact_group';
    
}
