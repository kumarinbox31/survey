<?php 
class Logs extends My_Model{
    protected $table = 'db_logs';
    
}
