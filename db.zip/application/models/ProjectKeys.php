<?php 
class ProjectKeys extends My_Model{
    protected $table = 'db_project_keys';
    
}
