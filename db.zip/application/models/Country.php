<?php 
class Country extends My_Model{
    protected $table = 'db_country';
    
}
