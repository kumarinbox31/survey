<?php
class ProjectStatus extends My_Model{
    protected $table = 'db_project_status';
}