<li class="nav-item menu-items">
    <a class="nav-link" href="<?= base_url('back/dashboard'); ?>">
        <span class="menu-icon">
            <i class="mdi mdi-speedometer"></i>
        </span>
        <span class="menu-title">Dashboard</span>
    </a>
</li>
<li class="nav-item menu-items">
    <a class="nav-link" href="<?= base_url('back/contact'); ?>">
        <span class="menu-icon">
            <i class="mdi mdi-speedometer"></i>
        </span>
        <span class="menu-title">Manage Contact</span>
    </a>
</li>
<li class="nav-item menu-items">
    <a class="nav-link" href="<?= base_url('back/project'); ?>">
        <span class="menu-icon">
            <i class="mdi mdi-speedometer"></i>
        </span>
        <span class="menu-title">Manage Project</span>
    </a>
</li>
<li class="nav-item menu-items">
    <a class="nav-link" href="<?= base_url('back/user'); ?>">
        <span class="menu-icon">
            <i class="mdi mdi-speedometer"></i>
        </span>
        <span class="menu-title">Manage User</span>
    </a>
</li>
<li class="nav-item menu-items">
    <a class="nav-link" href="<?= base_url('back/setting'); ?>">
        <span class="menu-icon">
            <i class="mdi mdi-speedometer"></i>
        </span>
        <span class="menu-title">Setting</span>
    </a>
</li>